# VTS book builder (v5.2)
Imágenes reales en images/ (portada, logos, PDCA, SB, VD, WB). Edita data/VTS_manual_content.xlsx y ejecuta el notebook.
