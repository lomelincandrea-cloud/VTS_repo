# VTS Plant Catalogue builder (v3)
Edita data/VTS_plant_catalogue.xlsx; fotos en images/ con el Plant ID (PL-001.jpg); hoja Photo_worklist con enlaces para buscar fotos con licencia.
